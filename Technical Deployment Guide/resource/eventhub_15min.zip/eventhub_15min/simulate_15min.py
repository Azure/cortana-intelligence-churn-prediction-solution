#https://azure.microsoft.com/en-us/documentation/articles/web-sites-python-create-deploy-bottle-app/

import sys
import os

sys.path.insert(0, ".")
sys.path.insert(0, 'azure.zip')
sys.path.insert(0, 'pytz.zip')



from datetime import datetime, timedelta

from pytz import timezone

import pytz

import math

import pickle

import time

from time import gmtime, strftime

from azure.servicebus import ServiceBusService
#from azure.common import AzureHttpError



#os.environ["EventHubServiceNamespace"] = "daden1churn2"
#os.environ["EventHub"] = "daden1churn2"
#os.environ["EventHubServicePolicy"] = "RootManageSharedAccessKey"
#os.environ["EventHubServiceKey"] = "yBE8vJMAje3Z2+uP6Vyy3WbytL8M43sVU6eutNXj8n4="




def convert_time(time):
    return datetime.strptime(time,"%Y-%m-%d %H:%M:%S")



if __name__ == "__main__":

    api_key = {}




    api_key["namespace"] = os.environ["EventHubServiceNamespace"]
    api_key["eventhubname"] = os.environ["EventHub"]
    api_key["policy_name"] =  os.environ["EventHubServicePolicy"]
    api_key["policy_secret"] = os.environ["EventHubServiceKey"]

    sbs = ServiceBusService(api_key["namespace"], shared_access_key_name=api_key["policy_name"], shared_access_key_value=api_key["policy_secret"])


    template = pickle.load( open( "activity.p", "rb" ) ) 


    start_time = None

    time_zone = timezone("UTC")


    start_file = "starttime"
    if os.path.isfile(start_file):
        f = open(start_file,'r')
        timestr = f.readline().rstrip()
        start_time = convert_time(timestr).replace(tzinfo=pytz.UTC)
        f.close()
    else:
        start_time = datetime.now(time_zone)
        f = open(start_file,'w')
        f.write(start_time.strftime('%Y-%m-%d %H:%M:%S'))

    print start_time
    start_day = 31+29;
    #day_of_year = datetime.now().timetuple().tm_yday

    current_time = datetime.now(time_zone)
    print current_time

    

    total_events = 0
    realtime = True
    iteration = start_day
    while iteration <= max(template.keys()):
        iteration += 1
        to_send = []
        total_15minutes = long(((current_time - start_time).total_seconds())/(15*60))
        days = total_15minutes
        temp = start_time + timedelta(days=days)
        # set it to the beginning of the day
        simulate_time = datetime(temp.year, temp.month, temp.day, tzinfo=pytz.UTC)
        i = int(days)+start_day
        if i > max(template.keys()):
            print i
            break


        print "i:%d, message number: %d" %(i,len(template[i]))
        for row in template[i]:
            temp = """{"TransactionId": %d,"Timestamp":"%s","UserId":%s,"ItemId": %d, "Quantity":%d, "Value": %f, "ProductCategory": "%s","Location":"%s"}""" %(row[0],simulate_time.strftime('%Y-%m-%d %H:%M:%S'),row[1], row[2], row[3], row[4], row[5], row[6])
            to_send.append(temp)
            """k +=1
            if k==3:
                break
            """
        left = len(to_send)
        batch_size = 1000
        while left > 0:
            start = len(to_send) - left
            end = min(start+batch_size, len(to_send))
            message =  '['+','.join(to_send[int(start):int(end)])+']'
            print len(message)
            if len(message) > 262144:
                batch_size = batch_size/2
                print batch_size
                continue
            else:
                #try:
                sbs.send_event(api_key['eventhubname'],message)
                #except Exception as e:
                #    print "Unexpected error:", sys.exc_info()[0]
                #    continue
                left -= batch_size

        total_events += len(to_send)
        print "message length %d, total_message %d" %(len(to_send), total_events)
        # for cron job, only sent once
        break 
        #current_time = current_time + timedelta(minutes=15)
